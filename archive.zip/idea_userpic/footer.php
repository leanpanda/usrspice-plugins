<?php
//Please don't load code on the footer of every page if you don't need it on the footer of every page.

     $userID = '123456';
	 $userID = $user->data()->id;

echo '<script>
function changeImage() {
  let img = document.querySelector(".profile-replacer");
  img.src = "https://picsum.photos/seed/' . $userID . '/200";
}
window.onload = changeImage;
</script>';


